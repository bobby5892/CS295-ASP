﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace community.Models
{
    public class LocationViewModel
    {
        public List<Location> Locations = new List<Location>();
    }
}
