﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace community.Models
{
    public class PersonsViewModel
    {
        public List<Person> Persons = new List<Person>();
    }
}
